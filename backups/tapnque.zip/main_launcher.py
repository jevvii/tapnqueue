"""
Main Launcher for Student Kiosk Ticketing System
Provides menu to launch all application modules
"""

import sys
import os
from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
                               QLabel, QPushButton, QMessageBox, QFrame)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


class MainLauncher(QWidget):
    """Main launcher window to open different modules."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🎓 Student Kiosk Ticketing System")
        self.setMinimumSize(600, 500)
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup launcher UI."""
        self.setStyleSheet("""
            QWidget {
                background-color: #1a1a2e;
            }
            QLabel {
                color: #ffffff;
            }
            QPushButton {
                background-color: #16213e;
                color: #ffffff;
                border: 2px solid #0f3460;
                border-radius: 12px;
                padding: 20px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #0f3460;
                border: 2px solid #e94560;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(40, 40, 40, 40)
        
        # Title
        title = QLabel("🎓 STUDENT KIOSK\nTICKETING SYSTEM")
        title.setFont(QFont("Arial", 28, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #e94560;")
        layout.addWidget(title)
        
        subtitle = QLabel("Select a module to launch:")
        subtitle.setFont(QFont("Arial", 14))
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color: #a0a0a0;")
        layout.addWidget(subtitle)
        
        layout.addSpacing(30)
        
        # Module buttons
        # Student Kiosk
        kiosk_btn = self._create_module_button(
            "🎟️", "Student Kiosk", 
            "For students to get queue tickets",
            self._open_student_kiosk
        )
        layout.addWidget(kiosk_btn)
        
        # Live Display
        live_btn = self._create_module_button(
            "📺", "Live Display", 
            "Public monitor showing queue status",
            self._open_live_display
        )
        layout.addWidget(live_btn)
        
        # Staff Admin
        staff_btn = self._create_module_button(
            "💼", "Staff Admin", 
            "Counter staff interface for calling tickets",
            self._open_staff_admin
        )
        layout.addWidget(staff_btn)
        
        # Super Admin
        admin_btn = self._create_module_button(
            "🔧", "Super Admin", 
            "Analytics dashboard and system management",
            self._open_super_admin
        )
        layout.addWidget(admin_btn)
        
        layout.addSpacing(20)
        
        # Info
        info = QLabel("💡 Tip: Run multiple modules simultaneously\nto test the full queue system!")
        info.setFont(QFont("Arial", 10))
        info.setAlignment(Qt.AlignCenter)
        info.setStyleSheet("color: #666;")
        layout.addWidget(info)
        
        self.setLayout(layout)
    
    def _create_module_button(self, icon, title, description, callback):
        """Create a module selection button."""
        btn = QPushButton()
        btn.setMinimumHeight(80)
        
        text = f"{icon} {title}\n{description}"
        btn.setText(text)
        btn.setFont(QFont("Arial", 12))
        btn.clicked.connect(callback)
        
        return btn
    
    def _open_student_kiosk(self):
        """Open Student Kiosk module."""
        from student_kiosk import StudentKiosk
        self.kiosk_window = StudentKiosk()
        self.kiosk_window.show()
        QMessageBox.information(self, "Opened", "Student Kiosk window opened!")
    
    def _open_live_display(self):
        """Open Live Display module."""
        from live_display_monitor import LiveDisplayMonitor
        self.live_window = LiveDisplayMonitor()
        self.live_window.show()
        QMessageBox.information(self, "Opened", "Live Display window opened!")
    
    def _open_staff_admin(self):
        """Open Staff Admin module."""
        from staff_admin import StaffAdmin
        self.staff_window = StaffAdmin()
        if not self.staff_window.authenticated:
            QMessageBox.information(self, "Access Cancelled", "Staff Admin was not opened.")
            return
        self.staff_window.show()
        QMessageBox.information(self, "Opened", "Staff Admin window opened!")
    
    def _open_super_admin(self):
        """Open Super Admin module."""
        from super_admin import SuperAdmin
        self.admin_window = SuperAdmin()
        if not self.admin_window.authenticated:
            QMessageBox.information(self, "Access Cancelled", "Super Admin was not opened.")
            return
        self.admin_window.show()
        QMessageBox.information(self, "Opened", "Super Admin window opened!")


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    window = MainLauncher()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
