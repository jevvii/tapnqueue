"""
Update staff or super admin login credentials.

Examples:
  python set_admin_password.py staff newstaff strong-password
  python set_admin_password.py super_admin newadmin strong-password
"""

import json
import sys

from admin_auth import AUTH_FILE, _build_user, ensure_auth_file


VALID_ROLES = {"staff", "super_admin"}


def main():
    if len(sys.argv) != 4 or sys.argv[1] not in VALID_ROLES:
        roles = ", ".join(sorted(VALID_ROLES))
        raise SystemExit(
            "Usage: python set_admin_password.py <role> <username> <password>\n"
            f"Roles: {roles}"
        )

    role, username, password = sys.argv[1], sys.argv[2], sys.argv[3]
    if not username.strip() or not password:
        raise SystemExit("Username and password cannot be empty.")

    ensure_auth_file()
    users = json.loads(AUTH_FILE.read_text(encoding="utf-8"))
    users[role] = _build_user(username.strip(), password)
    AUTH_FILE.write_text(json.dumps(users, indent=2), encoding="utf-8")
    print(f"Updated {role} login for user '{username.strip()}'.")


if __name__ == "__main__":
    main()
