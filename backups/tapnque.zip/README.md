# Student Kiosk Ticketing System

A complete PySide6-based queue management system for educational institutions.

## 📁 Project Structure

```
├── database_manager.py   # JSON database interface
├── student_kiosk.py      # Student ticket entry UI
├── live_display.py       # Public monitor with sound
├── staff_admin.py        # Counter staff interface
├── super_admin.py        # Analytics dashboard
├── main_launcher.py     # Main menu launcher
├── notify.wav           # Notification sound (add your own)
└── queue_db.json        # Auto-generated database
```

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install PySide6
```

### 2. Run the System
```bash
python main_launcher.py
```

### 3. Open Multiple Windows
- **Student Kiosk**: For students to get tickets
- **Live Display**: Public monitor (shows queue)
- **Staff Admin**: Counter staff calls tickets
- **Super Admin**: Analytics and settings

## 🎨 Features

### Student Kiosk
- Large, high-contrast buttons for easy use
- Fields: Name, Student ID, Email, Phone, Purpose
- Thermal receipt-style print dialog
- PDF export fallback

### Live Display
- Real-time "Now Serving" display
- Waiting list with wait times
- Sound notification (ding) on new ticket
- Auto-refresh every 2 seconds

### Staff Admin
- 3 counter buttons (Call Next, Recall, Done)
- Dark-mode professional theme
- Queue management table

### Super Admin
- Statistics dashboard (total served, avg wait)
- Queue management with export

## 🔧 Technical Details

### Database
- Uses local JSON file (`queue_db.json`)
- No cloud backend is configured

### Printing
- Uses QtPrintSupport for thermal printer support
- 58mm receipt width styling
- PDF export fallback included

### Sound
- Uses PySide6.QtMultimedia
- Placeholder for `notify.wav` - add your own sound file

## 🎫 Thermal Printer Setup

The system is designed for 58mm or 80mm thermal printers:
- Receipt width: ~220px at 300 DPI
- Uses fixed-width font (Consolas)
- Print dialog with PDF fallback

## 📝 Requirements

- Python 3.8+
- PySide6

## Admin Login

Staff Admin and Super Admin are protected by a local login dialog.

Default logins:
- Staff Admin: username `staff`, password `staff123`
- Super Admin: username `admin`, password `admin123`

Change them before regular use:

```bash
python set_admin_password.py staff newstaff strong-password
python set_admin_password.py super_admin newadmin strong-password
```

Credentials are saved in `admin_users.json` as salted password hashes.
