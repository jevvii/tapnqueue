import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

SENDER_EMAIL = os.getenv("TAPNQUE_SENDER_EMAIL", "jahziel377@gmail.com").strip()
SENDER_PASSWORD = os.getenv("TAPNQUE_SENDER_PASSWORD", "covy fvku bxst ozpr").strip()


def is_email_configured():
    return bool(SENDER_EMAIL and SENDER_PASSWORD)


def _send_email(to_email, subject, body):
    try:
        if not is_email_configured() or not to_email:
            return False

        msg = MIMEMultipart()
        msg["From"] = SENDER_EMAIL
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.sendmail(SENDER_EMAIL, to_email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        print("Email failed:", e)
        return False


def send_ticket_email(to_email, student_name, ticket_number, position, reason):
    subject = f"Your Ticket #{ticket_number}"
    body = f"""
Hello {student_name},

Your Ticket Number: {ticket_number}
Position in Line: {position}
Reason: {reason}

Please wait for your number to be called.

- TapNQue
"""
    return _send_email(to_email, subject, body)


def send_called_email(to_email, student_name, ticket_number, reason):
    subject = f"Ticket #{ticket_number} - Please Proceed"
    body = f"""
Hello {student_name},

Your ticket #{ticket_number} for "{reason}" is NOW BEING CALLED.

Please proceed to the counter within 3 minutes.
If you do not arrive on time, your ticket may be skipped.

- TapNQue
"""
    return _send_email(to_email, subject, body)


def send_served_email(to_email, student_name, ticket_number, reason):
    subject = f"Your Ticket #{ticket_number} Has Been Served"
    body = f"""
Hello {student_name},

Your ticket #{ticket_number} for "{reason}" has now been served.

Thank you for using TapNQue!
"""
    return _send_email(to_email, subject, body)
