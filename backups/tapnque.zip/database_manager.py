"""
Database Manager for Student Kiosk Ticketing System
SQLite-backed local database interface used by the kiosk and web admin.
"""

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


class DatabaseManager:
    """Central database interface backed by the local SQLite database."""

    def __init__(self, db_file: Optional[str] = None):
        self.db_file = Path(db_file).resolve() if db_file else Path(__file__).resolve().parent / "kiosk.db"
        self._initialize_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_file)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _row_to_dict(self, row: Optional[sqlite3.Row]) -> Optional[Dict[str, Any]]:
        if row is None:
            return None
        return {key: row[key] for key in row.keys()}

    def _default_data(self) -> Dict[str, Any]:
        """Return the default application state."""
        return {
            "current_ticket": 0,
            "served_tickets": [],
            "waiting_queue": [],
            "counters": [
                {"id": 1, "name": "Counter 1", "status": "available"},
                {"id": 2, "name": "Counter 2", "status": "available"},
                {"id": 3, "name": "Counter 3", "status": "available"},
            ],
            "statistics": {
                "total_served": 0,
                "total_wait_time": 0,
                "average_wait_time": 0,
            },
            "settings": {
                "phone_number_enabled": True,
            },
        }

    def _initialize_db(self):
        """Initialize the SQLite database and default data if it doesn't exist."""
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS tickets (
                    ticket_number INTEGER PRIMARY KEY,
                    name TEXT,
                    student_id TEXT,
                    email TEXT,
                    phone TEXT,
                    visitor_type TEXT,
                    purpose TEXT,
                    priority_type TEXT DEFAULT 'Standard',
                    created_at TEXT,
                    called_at TEXT,
                    recalled_at TEXT,
                    completed_at TEXT,
                    status TEXT DEFAULT 'waiting',
                    counter_id INTEGER,
                    wait_time REAL,
                    prioritized_at TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS counters (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    status TEXT,
                    current_ticket INTEGER
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS statistics (
                    key TEXT PRIMARY KEY,
                    value REAL NOT NULL
                )
                """
            )

            default_counters = [
                (1, "Counter 1", "available", None),
                (2, "Counter 2", "available", None),
                (3, "Counter 3", "available", None),
            ]
            existing = conn.execute("SELECT id FROM counters").fetchall()
            existing_ids = {row[0] for row in existing}
            for counter in default_counters:
                if counter[0] not in existing_ids:
                    conn.execute(
                        "INSERT INTO counters (id, name, status, current_ticket) VALUES (?, ?, ?, ?)",
                        counter,
                    )

            if conn.execute("SELECT COUNT(*) FROM settings").fetchone()[0] == 0:
                conn.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?)",
                    ("phone_number_enabled", "1"),
                )

            if conn.execute("SELECT COUNT(*) FROM statistics").fetchone()[0] == 0:
                conn.executemany(
                    "INSERT INTO statistics (key, value) VALUES (?, ?)",
                    [
                        ("total_served", 0),
                        ("total_wait_time", 0),
                        ("average_wait_time", 0),
                    ],
                )

        self._migrate_legacy_json_if_needed()

    def _migrate_legacy_json_if_needed(self):
        """Import existing queue_db.json data into SQLite once, if present and DB is empty."""
        legacy_path = Path(__file__).resolve().parent / "queue_db.json"
        if not legacy_path.exists():
            return

        with self._connect() as conn:
            if conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0] > 0:
                return

            try:
                with open(legacy_path, "r", encoding="utf-8") as f:
                    legacy = json.load(f)
            except (OSError, ValueError, TypeError):
                return

            waiting_queue = legacy.get("waiting_queue", [])
            served_tickets = legacy.get("served_tickets", [])
            counters = legacy.get("counters", [])
            settings = legacy.get("settings", {})
            stats = legacy.get("statistics", {})

            for ticket in waiting_queue + served_tickets:
                conn.execute(
                    """
                    INSERT INTO tickets (
                        ticket_number, name, student_id, email, phone, visitor_type,
                        purpose, priority_type, created_at, called_at, recalled_at,
                        completed_at, status, counter_id, wait_time, prioritized_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ticket.get("ticket_number"),
                        ticket.get("name"),
                        ticket.get("student_id"),
                        ticket.get("email"),
                        ticket.get("phone"),
                        ticket.get("visitor_type"),
                        ticket.get("purpose"),
                        ticket.get("priority_type", "Standard"),
                        ticket.get("created_at"),
                        ticket.get("called_at"),
                        ticket.get("recalled_at"),
                        ticket.get("completed_at"),
                        ticket.get("status", "waiting"),
                        ticket.get("counter_id"),
                        ticket.get("wait_time"),
                        ticket.get("prioritized_at"),
                    ),
                )

            for counter in counters:
                conn.execute(
                    "INSERT OR REPLACE INTO counters (id, name, status, current_ticket) VALUES (?, ?, ?, ?)",
                    (counter.get("id"), counter.get("name"), counter.get("status"), counter.get("current_ticket")),
                )

            if settings:
                conn.execute(
                    "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                    ("phone_number_enabled", "1" if settings.get("phone_number_enabled", True) else "0"),
                )

            if stats:
                conn.executemany(
                    "INSERT OR REPLACE INTO statistics (key, value) VALUES (?, ?)",
                    [
                        ("total_served", float(stats.get("total_served", 0))),
                        ("total_wait_time", float(stats.get("total_wait_time", 0))),
                        ("average_wait_time", float(stats.get("average_wait_time", 0))),
                    ],
                )

    def _save_local_data(self, data: Dict[str, Any]):
        """Legacy compatibility helper for any code that still relies on queue_db.json."""
        legacy_path = Path(__file__).resolve().parent / "queue_db.json"
        with open(legacy_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _load_data(self) -> Dict:
        """Load data from SQLite in the legacy dict shape used by the older UI."""
        return {
            "current_ticket": self.get_next_ticket_number() - 1,
            "waiting_queue": self.get_waiting_queue(),
            "served_tickets": self.get_served_tickets(),
            "counters": self.get_counters(),
            "statistics": self.get_statistics(),
            "settings": self.get_app_settings(),
        }

    def _save_data(self, data: Dict):
        """Compatibility save helper for legacy callers. Writes JSON and keeps SQLite in sync."""
        self._save_local_data(data)

    # ==================== Ticket Operations ====================

    def get_next_ticket_number(self) -> int:
        """Get the next ticket number."""
        with self._connect() as conn:
            row = conn.execute("SELECT COALESCE(MAX(ticket_number), 0) + 1 AS next_number FROM tickets").fetchone()
            return int(row["next_number"]) if row else 1

    def create_ticket(
        self,
        name: str,
        student_id: str,
        email: str,
        phone: str,
        purpose: str,
        visitor_type: str = "Student",
    ) -> Dict:
        """Create a new ticket and add to waiting queue."""
        ticket_number = self.get_next_ticket_number()
        timestamp = datetime.now().isoformat()

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO tickets (
                    ticket_number, name, student_id, email, phone, visitor_type,
                    purpose, priority_type, created_at, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    ticket_number,
                    name,
                    student_id,
                    email,
                    phone,
                    visitor_type,
                    purpose,
                    "Standard",
                    timestamp,
                    "waiting",
                ),
            )

        return {
            "ticket_number": ticket_number,
            "name": name,
            "student_id": student_id,
            "email": email,
            "phone": phone,
            "visitor_type": visitor_type,
            "purpose": purpose,
            "priority_type": "Standard",
            "created_at": timestamp,
            "status": "waiting",
        }

    def get_waiting_queue(self) -> List[Dict]:
        """Get all waiting tickets."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM tickets
                WHERE status = 'waiting'
                ORDER BY CASE priority_type
                    WHEN 'Urgent' THEN 0
                    WHEN 'High' THEN 1
                    ELSE 2
                END, ticket_number ASC
                """
            ).fetchall()
            return [self._row_to_dict(row) for row in rows]

    def get_served_tickets(self) -> List[Dict]:
        """Get all served tickets for the history table."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM tickets
                WHERE status IN ('serving', 'recalled', 'completed')
                ORDER BY ticket_number DESC
                """
            ).fetchall()
            return [self._row_to_dict(row) for row in rows]

    # ==================== Counter Operations ====================

    def get_counters(self) -> List[Dict]:
        """Get all counters."""
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM counters ORDER BY id ASC").fetchall()
            return [self._row_to_dict(row) for row in rows]

    def update_counter_status(self, counter_id: int, status: str):
        """Update counter status."""
        with self._connect() as conn:
            conn.execute(
                "UPDATE counters SET status = ? WHERE id = ?",
                (status, counter_id),
            )

    # ==================== Queue Management ====================

    def call_next_ticket(self, counter_id: int) -> Optional[Dict]:
        """Call the next ticket in queue."""
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT * FROM tickets
                WHERE status = 'waiting'
                ORDER BY CASE priority_type
                    WHEN 'Urgent' THEN 0
                    WHEN 'High' THEN 1
                    ELSE 2
                END, ticket_number ASC
                LIMIT 1
                """
            ).fetchone()
            if row is None:
                return None

            now = datetime.now().isoformat()
            ticket_number = row["ticket_number"]
            conn.execute(
                "UPDATE tickets SET status = 'serving', called_at = ?, counter_id = ? WHERE ticket_number = ?",
                (now, counter_id, ticket_number),
            )
            conn.execute(
                "UPDATE counters SET status = 'busy', current_ticket = ? WHERE id = ?",
                (ticket_number, counter_id),
            )
            updated_row = conn.execute("SELECT * FROM tickets WHERE ticket_number = ?", (ticket_number,)).fetchone()
            return self._row_to_dict(updated_row)

    def prioritize_waiting_ticket(self, ticket_number: int, priority_type: str) -> Optional[Dict]:
        """Move a waiting ticket to the front of the queue with a priority label."""
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tickets WHERE ticket_number = ? AND status = 'waiting'", (ticket_number,)).fetchone()
            if row is None:
                return None

            now = datetime.now().isoformat()
            conn.execute(
                "UPDATE tickets SET priority_type = ?, prioritized_at = ? WHERE ticket_number = ?",
                (priority_type, now, ticket_number),
            )
            updated_row = conn.execute("SELECT * FROM tickets WHERE ticket_number = ?", (ticket_number,)).fetchone()
            return self._row_to_dict(updated_row)

    def clear_ticket_priority(self, ticket_number: int) -> Optional[Dict]:
        """Remove priority from a waiting ticket."""
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tickets WHERE ticket_number = ? AND status = 'waiting'", (ticket_number,)).fetchone()
            if row is None:
                return None

            conn.execute(
                "UPDATE tickets SET priority_type = 'Standard', prioritized_at = NULL WHERE ticket_number = ?",
                (ticket_number,),
            )
            updated_row = conn.execute("SELECT * FROM tickets WHERE ticket_number = ?", (ticket_number,)).fetchone()
            return self._row_to_dict(updated_row)

    def recall_ticket(self, ticket_number: int) -> Optional[Dict]:
        """Recall a specific ticket."""
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tickets WHERE ticket_number = ? AND status IN ('serving', 'recalled')", (ticket_number,)).fetchone()
            if row is None:
                return None

            now = datetime.now().isoformat()
            conn.execute(
                "UPDATE tickets SET status = 'recalled', recalled_at = ? WHERE ticket_number = ?",
                (now, ticket_number),
            )
            updated_row = conn.execute("SELECT * FROM tickets WHERE ticket_number = ?", (ticket_number,)).fetchone()
            return self._row_to_dict(updated_row)

    def mark_ticket_done(self, ticket_number: int) -> Dict:
        """Mark a ticket as completed."""
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tickets WHERE ticket_number = ?", (ticket_number,)).fetchone()
            if row is None:
                return {"status": "not_found", "ticket_number": ticket_number}

            completed_at = datetime.now().isoformat()
            wait_time = 0.0
            if row["called_at"]:
                created_at = datetime.fromisoformat(row["created_at"])
                called_at = datetime.fromisoformat(row["called_at"])
                wait_time = (called_at - created_at).total_seconds()
            if row["completed_at"] is not None:
                wait_time = float(row["wait_time"]) if row["wait_time"] is not None else 0.0

            conn.execute(
                "UPDATE tickets SET status = 'completed', completed_at = ?, wait_time = ? WHERE ticket_number = ?",
                (completed_at, wait_time, ticket_number),
            )

            conn.execute(
                "UPDATE counters SET status = 'available', current_ticket = NULL WHERE current_ticket = ?",
                (ticket_number,),
            )

            stats_rows = conn.execute("SELECT key, value FROM statistics").fetchall()
            stats = {row["key"]: float(row["value"]) for row in stats_rows}
            stats["total_served"] = int(stats.get("total_served", 0)) + 1
            stats["total_wait_time"] = float(stats.get("total_wait_time", 0)) + float(wait_time)
            stats["average_wait_time"] = (
                stats["total_wait_time"] / stats["total_served"] if stats["total_served"] else 0
            )

            conn.executemany(
                "INSERT INTO statistics (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                [
                    ("total_served", float(stats.get("total_served", 0))),
                    ("total_wait_time", float(stats.get("total_wait_time", 0))),
                    ("average_wait_time", float(stats.get("average_wait_time", 0))),
                ],
            )

        return {"status": "completed", "ticket_number": ticket_number}

    def get_currently_serving(self) -> List[Dict]:
        """Get tickets currently being served."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM tickets WHERE status IN ('serving', 'recalled') ORDER BY ticket_number ASC"
            ).fetchall()
            return [self._row_to_dict(row) for row in rows]

    # ==================== Statistics ====================

    def _save_statistics(self, stats: Dict):
        """Persist statistics values into the SQLite statistics table."""
        with self._connect() as conn:
            conn.executemany(
                "INSERT INTO statistics (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                [
                    ("total_served", float(stats.get("total_served", 0))),
                    ("total_wait_time", float(stats.get("total_wait_time", 0))),
                    ("average_wait_time", float(stats.get("average_wait_time", 0))),
                ],
            )

    def get_statistics(self) -> Dict:
        """Get system statistics."""
        with self._connect() as conn:
            rows = conn.execute("SELECT key, value FROM statistics").fetchall()
            values = {row["key"]: float(row["value"]) for row in rows}
            return {
                "total_served": int(values.get("total_served", 0)),
                "total_wait_time": float(values.get("total_wait_time", 0)),
                "average_wait_time": float(values.get("average_wait_time", 0)),
            }

    def reset_statistics(self):
        """Reset all statistics (admin only)."""
        self._save_statistics({
            "total_served": 0,
            "total_wait_time": 0,
            "average_wait_time": 0,
        })

    # ==================== App Settings ====================

    def get_app_settings(self) -> Dict[str, Any]:
        """Get application settings with defaults for older database files."""
        with self._connect() as conn:
            row = conn.execute("SELECT value FROM settings WHERE key = 'phone_number_enabled'").fetchone()
            enabled = bool(int(row["value"])) if row else True
            return {"phone_number_enabled": enabled}

    def get_cached_app_settings(self) -> Dict[str, Any]:
        """Get application settings from the database without network access."""
        return self.get_app_settings()

    def set_phone_number_enabled(self, enabled: bool):
        """Show or hide the kiosk phone number field."""
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO settings (key, value) VALUES ('phone_number_enabled', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                ("1" if bool(enabled) else "0",),
            )


_db_instance = None


def get_database() -> DatabaseManager:
    """Get the singleton database instance."""
    global _db_instance
    if _db_instance is None:
        _db_instance = DatabaseManager()
    return _db_instance
