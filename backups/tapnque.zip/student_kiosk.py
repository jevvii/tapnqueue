"""
Student Kiosk Ticketing System - User Data Entry UI
Single-page kiosk form styled after a modern queue registration screen.
"""

import sys
from pathlib import Path

from PySide6.QtCore import QEvent, QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from database_manager import get_database
from email_sender2 import is_email_configured, send_ticket_email


class AnimatedSpinner(QWidget):
    """Minimal rotating loader used by the startup splash."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.angle = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._advance)
        self.timer.start(16)
        self.setFixedSize(66, 66)

    def _advance(self):
        self.angle = (self.angle + 6) % 360
        self.update()

    def paintEvent(self, event):
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)

        rect = QRectF(8, 8, self.width() - 16, self.height() - 16)

        painter.setPen(QPen(QColor(7, 53, 42, 185), 4))
        painter.drawEllipse(rect)

        painter.setPen(QPen(QColor("#0b9b4a"), 4, Qt.SolidLine, Qt.RoundCap))
        painter.drawArc(rect, int(-self.angle * 16), -110 * 16)

        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#0b9b4a"))
        painter.drawEllipse(QRectF(self.width() / 2 - 4, self.height() / 2 - 4, 8, 8))


class AnimatedLoadingBar(QWidget):
    """Subtle moving line animation for the footer."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.offset = 0.0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._advance)
        self.timer.start(24)
        self.setFixedHeight(14)

    def sizeHint(self):
        return QSize(560, 14)

    def _advance(self):
        self.offset = (self.offset + 0.012) % 1.2
        self.update()

    def paintEvent(self, event):
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)

        line_y = self.height() / 2
        line_start = 0
        line_end = self.width()

        painter.setPen(QPen(QColor(34, 48, 67, 190), 3, Qt.SolidLine, Qt.RoundCap))
        painter.drawLine(line_start, int(line_y), line_end, int(line_y))

        segment_width = max(110, int(self.width() * 0.22))
        span = self.width() + segment_width
        segment_x = int((self.offset * span) - segment_width)

        gradient = QLinearGradient(segment_x, 0, segment_x + segment_width, 0)
        gradient.setColorAt(0.0, QColor(11, 155, 74, 0))
        gradient.setColorAt(0.5, QColor(11, 155, 74, 255))
        gradient.setColorAt(1.0, QColor(11, 155, 74, 0))

        painter.setPen(QPen(gradient, 3, Qt.SolidLine, Qt.RoundCap))
        painter.drawLine(segment_x, int(line_y), segment_x + segment_width, int(line_y))


class WaitingSignalAnimation(QWidget):
    """Animated equalizer-like signal for the post-ticket waiting screen."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.phase = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._advance)
        self.timer.start(80)
        self.setFixedSize(170, 72)

    def _advance(self):
        self.phase = (self.phase + 1) % 24
        self.update()

    def paintEvent(self, event):
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)

        bar_width = 18
        gap = 10
        base_y = self.height() - 8
        heights = [20, 40, 56, 34, 48, 28]

        for index, base_height in enumerate(heights):
            wave = ((self.phase + index * 3) % 12) / 11.0
            height = int(18 + (base_height * (0.45 + wave * 0.55)))
            x = index * (bar_width + gap)
            y = base_y - height

            gradient = QLinearGradient(x, y, x, base_y)
            gradient.setColorAt(0.0, QColor("#4dd38a"))
            gradient.setColorAt(1.0, QColor("#0a8c3c"))

            painter.setPen(Qt.NoPen)
            painter.setBrush(gradient)
            painter.drawRoundedRect(x, y, bar_width, height, 9, 9)


class TicketCreatedDialog(QDialog):
    """Branded success screen shown after creating a ticket."""

    def __init__(self, ticket, queue_position, purpose, email_sent, parent=None):
        super().__init__(parent)
        self.ticket = ticket
        self.queue_position = queue_position
        self.purpose = purpose
        self.email_sent = email_sent
        self.logo_source = Path(__file__).resolve().parent / "OLFU LOGO 1.png"
        self._setup_ui()

        self.close_timer = QTimer(self)
        self.close_timer.setSingleShot(True)
        self.close_timer.timeout.connect(self.accept)
        self.close_timer.start(8000)

    def _setup_ui(self):
        self.setWindowTitle("Ticket Created")
        self.setModal(True)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setMinimumSize(860, 620)
        self.setStyleSheet(
            """
            TicketCreatedDialog {
                background: transparent;
            }
            QFrame#dialogCard {
                background: qlineargradient(
                    x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 #071912,
                    stop: 0.55 #0a2417,
                    stop: 1 #123223
                );
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 34px;
            }
            QFrame#ticketBadge {
                background: rgba(255, 255, 255, 0.08);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 28px;
            }
            QFrame#detailPanel {
                background: rgba(247, 251, 248, 0.07);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 24px;
            }
            QLabel#eyebrow {
                color: rgba(145, 226, 179, 0.92);
                font-size: 14px;
                font-weight: 800;
                letter-spacing: 3px;
            }
            QLabel#dialogTitle {
                color: #f4fbf6;
                font-size: 40px;
                font-weight: 900;
            }
            QLabel#dialogCopy {
                color: rgba(230, 240, 234, 0.86);
                font-size: 18px;
                line-height: 1.5;
            }
            QLabel#ticketNumber {
                color: #ffffff;
                font-size: 76px;
                font-weight: 900;
            }
            QLabel#ticketLabel {
                color: rgba(189, 224, 201, 0.86);
                font-size: 14px;
                font-weight: 700;
                letter-spacing: 3px;
            }
            QLabel#waitTitle {
                color: #f7fff8;
                font-size: 30px;
                font-weight: 900;
            }
            QLabel#waitCopy {
                color: rgba(224, 235, 228, 0.8);
                font-size: 18px;
            }
            QLabel#metaValue {
                color: #ffffff;
                font-size: 28px;
                font-weight: 800;
            }
            QLabel#metaLabel {
                color: rgba(185, 212, 194, 0.72);
                font-size: 13px;
                font-weight: 700;
                letter-spacing: 2px;
            }
            QLabel#statusPill {
                background: rgba(77, 211, 138, 0.16);
                color: #9ff1bf;
                border: 1px solid rgba(77, 211, 138, 0.35);
                border-radius: 16px;
                padding: 10px 18px;
                font-size: 14px;
                font-weight: 700;
            }
            QPushButton#doneButton {
                background: #4dd38a;
                color: #082114;
                border: none;
                border-radius: 18px;
                padding: 18px 26px;
                font-size: 18px;
                font-weight: 900;
            }
            QPushButton#doneButton:hover {
                background: #62e39b;
            }
            """
        )

        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(36, 36, 36, 36)

        card = QFrame()
        card.setObjectName("dialogCard")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(42, 36, 42, 32)
        card_layout.setSpacing(26)

        top_row = QHBoxLayout()
        top_row.setSpacing(18)

        logo_label = QLabel()
        logo_pixmap = QPixmap(str(self.logo_source))
        if not logo_pixmap.isNull():
            logo_label.setPixmap(logo_pixmap.scaled(58, 58, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo_label.setFixedSize(64, 64)
        logo_label.setAlignment(Qt.AlignCenter)
        top_row.addWidget(logo_label, 0, Qt.AlignTop)

        title_col = QVBoxLayout()
        title_col.setSpacing(6)

        eyebrow = QLabel("TICKET CONFIRMED")
        eyebrow.setObjectName("eyebrow")
        title_col.addWidget(eyebrow)

        title = QLabel("Please wait for your number to be called")
        title.setObjectName("dialogTitle")
        title.setWordWrap(True)
        title_col.addWidget(title)

        copy = QLabel(
            "Your queue request has been saved successfully. Stay near the display monitor and listen for your ticket number."
        )
        copy.setObjectName("dialogCopy")
        copy.setWordWrap(True)
        title_col.addWidget(copy)
        top_row.addLayout(title_col, 1)
        card_layout.addLayout(top_row)

        center_row = QHBoxLayout()
        center_row.setSpacing(24)

        badge = QFrame()
        badge.setObjectName("ticketBadge")
        badge_layout = QVBoxLayout(badge)
        badge_layout.setContentsMargins(28, 28, 28, 28)
        badge_layout.setSpacing(10)

        ticket_label = QLabel("YOUR TICKET")
        ticket_label.setObjectName("ticketLabel")
        ticket_label.setAlignment(Qt.AlignCenter)
        badge_layout.addWidget(ticket_label)

        ticket_number = QLabel(f"#{self.ticket['ticket_number']:04d}")
        ticket_number.setObjectName("ticketNumber")
        ticket_number.setAlignment(Qt.AlignCenter)
        badge_layout.addWidget(ticket_number)

        purpose_label = QLabel(self.purpose)
        purpose_label.setObjectName("dialogCopy")
        purpose_label.setAlignment(Qt.AlignCenter)
        badge_layout.addWidget(purpose_label)

        center_row.addWidget(badge, 1)

        detail_panel = QFrame()
        detail_panel.setObjectName("detailPanel")
        detail_layout = QVBoxLayout(detail_panel)
        detail_layout.setContentsMargins(28, 28, 28, 28)
        detail_layout.setSpacing(18)

        wait_title = QLabel("Now in waiting queue")
        wait_title.setObjectName("waitTitle")
        detail_layout.addWidget(wait_title)

        signal_animation = WaitingSignalAnimation()
        detail_layout.addWidget(signal_animation, 0, Qt.AlignLeft)

        wait_copy = QLabel("Please wait for your number to be called on screen.")
        wait_copy.setObjectName("waitCopy")
        wait_copy.setWordWrap(True)
        detail_layout.addWidget(wait_copy)

        meta_row = QHBoxLayout()
        meta_row.setSpacing(18)
        meta_row.addWidget(self._build_meta_block(str(self.queue_position), "QUEUE POSITION"))
        meta_row.addWidget(self._build_meta_block(self.ticket.get("visitor_type", "Student"), "VISITOR TYPE"))
        detail_layout.addLayout(meta_row)

        status_text = "Ticket also sent to your email." if self.email_sent else "Digital ticket ready on this screen."
        status_pill = QLabel(status_text)
        status_pill.setObjectName("statusPill")
        status_pill.setAlignment(Qt.AlignCenter)
        detail_layout.addWidget(status_pill, 0, Qt.AlignLeft)

        center_row.addWidget(detail_panel, 1)
        card_layout.addLayout(center_row)

        footer_row = QHBoxLayout()
        footer_row.addStretch()

        done_button = QPushButton("DONE")
        done_button.setObjectName("doneButton")
        done_button.setCursor(Qt.PointingHandCursor)
        done_button.clicked.connect(self.accept)
        footer_row.addWidget(done_button)
        card_layout.addLayout(footer_row)

        root_layout.addWidget(card)

    def _build_meta_block(self, value, label_text):
        block = QFrame()
        layout = QVBoxLayout(block)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        value_label = QLabel(value)
        value_label.setObjectName("metaValue")
        layout.addWidget(value_label)

        text_label = QLabel(label_text)
        text_label.setObjectName("metaLabel")
        layout.addWidget(text_label)
        return block

    def paintEvent(self, event):
        del event
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(4, 12, 8, 155))


class LoadingScreen(QWidget):
    """Fullscreen animated startup screen shown before the kiosk UI."""

    def __init__(self, target_window):
        super().__init__()
        self.target_window = target_window
        self.logo_source = Path(__file__).resolve().parent / "OLFU LOGO 1.png"
        self.status_messages = [
            "INITIALIZING TERMINAL SESSION",
            "SYNCING CAMPUS SERVICES",
            "PREPARING CHECK-IN SCREEN",
        ]
        self.status_index = 0
        self._finished = False
        self._setup_ui()

        self.status_timer = QTimer(self)
        self.status_timer.timeout.connect(self._advance_status)
        self.status_timer.start(900)

        self.finish_timer = QTimer(self)
        self.finish_timer.setSingleShot(True)
        self.finish_timer.timeout.connect(self._finish_loading)
        self.finish_timer.start(5000)

    def _setup_ui(self):
        self.setWindowTitle("TapNQue Loading")
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setStyleSheet(
            """
            LoadingScreen {
                background: transparent;
            }
            QFrame#logoBadge {
                background: rgba(17, 33, 43, 0.78);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 34px;
            }
            QLabel#titleLabel {
                color: #f6f5ef;
                font-size: 68px;
                font-weight: 900;
                letter-spacing: 1px;
            }
            QLabel#subtitleLabel {
                color: #46a864;
                font-size: 24px;
                font-weight: 700;
                letter-spacing: 6px;
            }
            QLabel#loadingCopy {
                color: rgba(247, 244, 235, 0.92);
                font-size: 17px;
                font-weight: 500;
            }
            QLabel#statusLabel {
                color: rgba(215, 212, 203, 0.5);
                font-size: 13px;
                font-weight: 600;
                letter-spacing: 3px;
            }
            QLabel#footerLabel {
                color: rgba(189, 192, 201, 0.4);
                font-size: 12px;
                font-weight: 700;
            }
            QLabel#lineLabel {
                color: rgba(189, 192, 201, 0.32);
                font-size: 16px;
                font-weight: 300;
            }
            """
        )

        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(64, 54, 64, 40)
        root_layout.setSpacing(0)
        root_layout.addStretch()

        center_layout = QVBoxLayout()
        center_layout.setSpacing(18)
        center_layout.setAlignment(Qt.AlignHCenter)

        badge = QFrame()
        badge.setObjectName("logoBadge")
        badge.setFixedSize(206, 206)
        badge_layout = QVBoxLayout(badge)
        badge_layout.setContentsMargins(24, 24, 24, 24)

        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignCenter)
        pixmap = QPixmap(str(self.logo_source))
        if not pixmap.isNull():
            scaled = pixmap.scaled(126, 126, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            logo_label.setPixmap(scaled)
        else:
            logo_label.setText("OLFU")
            logo_label.setStyleSheet("color: #0b9b4a; font-size: 38px; font-weight: 800;")
        badge_layout.addWidget(logo_label, 1, Qt.AlignCenter)

        center_layout.addWidget(badge, 0, Qt.AlignCenter)

        title = QLabel("TapNQue")
        title.setObjectName("titleLabel")
        title.setAlignment(Qt.AlignCenter)
        center_layout.addWidget(title)

        subtitle = QLabel("KIOSK TERMINAL")
        subtitle.setObjectName("subtitleLabel")
        subtitle.setAlignment(Qt.AlignCenter)
        center_layout.addWidget(subtitle)

        center_layout.addSpacing(56)

        spinner = AnimatedSpinner()
        center_layout.addWidget(spinner, 0, Qt.AlignCenter)

        loading_copy = QLabel("Please wait while loading....")
        loading_copy.setObjectName("loadingCopy")
        loading_copy.setAlignment(Qt.AlignCenter)
        center_layout.addWidget(loading_copy)

        center_layout.addSpacing(10)

        status_row = QHBoxLayout()
        status_row.setSpacing(14)
        left_line = QLabel("────")
        left_line.setObjectName("lineLabel")
        right_line = QLabel("────")
        right_line.setObjectName("lineLabel")
        self.status_label = QLabel(self.status_messages[self.status_index])
        self.status_label.setObjectName("statusLabel")
        self.status_label.setAlignment(Qt.AlignCenter)
        status_row.addStretch()
        status_row.addWidget(left_line)
        status_row.addWidget(self.status_label)
        status_row.addWidget(right_line)
        status_row.addStretch()
        center_layout.addLayout(status_row)

        root_layout.addLayout(center_layout)
        root_layout.addStretch()

        footer_layout = QVBoxLayout()
        footer_layout.setSpacing(12)

        footer_bar = AnimatedLoadingBar()
        footer_layout.addWidget(footer_bar, 0, Qt.AlignHCenter)

        footer_labels = QHBoxLayout()
        footer_labels.setContentsMargins(0, 0, 0, 0)
        footer_labels.setSpacing(24)

        terminal_label = QLabel("TERMINAL: K-01249")
        terminal_label.setObjectName("footerLabel")
        version_label = QLabel("VERSION: 4.2.0-STABLE")
        version_label.setObjectName("footerLabel")
        security_label = QLabel("STATUS: READY")
        security_label.setObjectName("footerLabel")

        footer_labels.addWidget(terminal_label)
        footer_labels.addStretch()
        footer_labels.addWidget(version_label)
        footer_labels.addStretch()
        footer_labels.addWidget(security_label)
        footer_layout.addLayout(footer_labels)

        root_layout.addLayout(footer_layout)

    def _advance_status(self):
        self.status_index = (self.status_index + 1) % len(self.status_messages)
        self.status_label.setText(self.status_messages[self.status_index])

    def _finish_loading(self):
        if self._finished:
            return
        self._finished = True
        self.status_timer.stop()
        self.target_window.showFullScreen()
        self.close()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self._finish_loading()
            return
        super().keyPressEvent(event)

    def paintEvent(self, event):
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)

        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0.0, QColor("#04151d"))
        gradient.setColorAt(0.55, QColor("#03101a"))
        gradient.setColorAt(1.0, QColor("#070913"))
        painter.fillRect(self.rect(), gradient)

        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(9, 38, 33, 42))
        painter.drawEllipse(int(self.width() * 0.22), int(self.height() * 0.12), 520, 520)

        painter.setBrush(QColor(16, 20, 44, 30))
        painter.drawEllipse(int(self.width() * 0.56), int(self.height() * 0.42), 620, 620)


class TouchKeyboardWidget(QFrame):
    """Touchscreen keyboard dock for kiosk inputs."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.target_input = None
        self.symbol_mode = False
        self.alpha_rows = []
        self._setup_ui()

    def _setup_ui(self):
        self.setObjectName("touchKeyboard")
        self.setFixedSize(920, 404)
        self.hide()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 22)
        layout.setSpacing(12)

        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(0, 0, 0, 4)
        header_layout.addStretch()
        self.close_button = self._make_key("CLOSE", width=108, object_name="keyboardCloseKey")
        self.close_button.clicked.connect(self._enter)
        header_layout.addWidget(self.close_button)
        layout.addLayout(header_layout)

        self.row1_buttons = []
        self.row2_buttons = []
        self.row3_buttons = []

        self.alpha_rows.append(self._build_alpha_row(list("QWERTYUIOP"), self.row1_buttons))
        self.alpha_rows.append(self._build_alpha_row(list("ASDFGHJKL"), self.row2_buttons))

        row3 = QHBoxLayout()
        row3.setSpacing(10)
        self.shift_button = self._make_key("SHIFT", width=108)
        self.shift_button.clicked.connect(self._toggle_shift)
        row3.addWidget(self.shift_button)
        for key in list("ZXCVBNM"):
            button = self._make_key(key)
            button.clicked.connect(lambda checked=False, value=key: self._insert_text(value))
            self.row3_buttons.append(button)
            row3.addWidget(button)
        self.backspace_button = self._make_key("⌫", width=108, object_name="keyboardDeleteKey")
        self.backspace_button.clicked.connect(self._backspace)
        row3.addWidget(self.backspace_button)
        layout.addLayout(row3)
        self.alpha_rows.append(row3)

        row4 = QHBoxLayout()
        row4.setSpacing(10)
        self.toggle_button = self._make_key("?123", width=96)
        self.toggle_button.clicked.connect(self._toggle_symbol_mode)
        row4.addWidget(self.toggle_button)

        self.space_button = self._make_key("SPACE", width=420)
        self.space_button.clicked.connect(lambda: self._insert_text(" "))
        row4.addWidget(self.space_button, 1)

        self.enter_button = self._make_key("ENTER", width=160, object_name="keyboardEnterKey")
        self.enter_button.clicked.connect(self._enter)
        row4.addWidget(self.enter_button)
        layout.addLayout(row4)
        self.alpha_rows.append(row4)

        numeric_grid = QGridLayout()
        numeric_grid.setContentsMargins(20, 20, 20, 20)
        numeric_grid.setHorizontalSpacing(24)
        numeric_grid.setVerticalSpacing(64)
        for value, row, column in [
            ("1", 0, 0), ("2", 0, 1), ("3", 0, 2),
            ("4", 1, 0), ("5", 1, 1), ("6", 1, 2),
            ("7", 2, 0), ("8", 2, 1), ("9", 2, 2),
            ("0", 3, 0), ("⌫", 3, 1), ("ENTER", 3, 2),
        ]:
            object_name = "keyboardKey"
            if value == "⌫":
                object_name = "keyboardDeleteKey"
            elif value == "ENTER":
                object_name = "keyboardEnterKey"
            button = self._make_key(value, object_name=object_name)
            button.setFixedSize(104, 56)
            if value == "⌫":
                button.clicked.connect(self._backspace)
            elif value == "ENTER":
                button.clicked.connect(self._enter)
            else:
                button.clicked.connect(lambda checked=False, text=value: self._insert_text(text))
            numeric_grid.addWidget(button, row, column)
        self.numeric_container = QFrame()
        numeric_wrap = QHBoxLayout(self.numeric_container)
        numeric_wrap.setContentsMargins(0, 8, 0, 56)
        numeric_wrap.addStretch()
        numeric_wrap.addLayout(numeric_grid)
        numeric_wrap.addStretch()
        self.numeric_container.setMinimumWidth(460)
        self.numeric_container.hide()
        layout.addWidget(self.numeric_container)

    def _build_alpha_row(self, keys, button_store):
        row = QHBoxLayout()
        row.setSpacing(10)
        for key in keys:
            button = self._make_key(key)
            button.clicked.connect(lambda checked=False, value=key: self._insert_text(value))
            row.addWidget(button)
            button_store.append(button)
        self.layout().addLayout(row)
        return row

    def _make_key(self, text, width=68, object_name="keyboardKey"):
        button = QPushButton(text)
        button.setObjectName(object_name)
        button.setCursor(Qt.PointingHandCursor)
        button.setMinimumHeight(68)
        button.setMinimumWidth(width)
        return button

    def attach_target(self, line_edit, keyboard_type):
        self.target_input = line_edit
        self.symbol_mode = False
        self._set_keyboard_type(keyboard_type)
        if self.parentWidget() is not None:
            self.raise_()
        self.show()

    def _set_keyboard_type(self, keyboard_type):
        show_alpha = keyboard_type == "alpha"
        for row in self.alpha_rows:
            self._set_layout_visible(row, show_alpha)
        self.numeric_container.setVisible(keyboard_type == "numeric")
        if show_alpha:
            self._refresh_alpha_keys()

    def _set_layout_visible(self, layout, visible):
        for index in range(layout.count()):
            widget = layout.itemAt(index).widget()
            if widget is not None:
                widget.setVisible(visible)

    def _toggle_shift(self):
        if self.symbol_mode:
            return
        buttons = self.row1_buttons + self.row2_buttons + self.row3_buttons
        use_lower = any(button.text().isupper() for button in buttons)
        for button in buttons:
            button.setText(button.text().lower() if use_lower else button.text().upper())

    def _toggle_symbol_mode(self):
        self.symbol_mode = not self.symbol_mode
        self._refresh_alpha_keys()

    def _refresh_alpha_keys(self):
        if self.symbol_mode:
            row1 = list("1234567890")
            row2 = ["@", ".", "_", "-", "+", "/", ":"]
            row3 = ["[", "]", "{", "}", "!", "?", "&"]
            self.toggle_button.setText("ABC")
        else:
            row1 = list("QWERTYUIOP")
            row2 = list("ASDFGHJKL")
            row3 = list("ZXCVBNM")
            self.toggle_button.setText("?123")

        for buttons, values in (
            (self.row1_buttons, row1),
            (self.row2_buttons, row2),
            (self.row3_buttons, row3),
        ):
            for index, button in enumerate(buttons):
                if index < len(values):
                    button.setText(values[index])
                    button.show()
                else:
                    button.hide()

    def _insert_text(self, text):
        if self.target_input is None:
            return
        numeric_format = self.target_input.property("numeric_format")
        if numeric_format == "student_id" and text.isdigit():
            digits = self._student_id_digits() + text
            digits = digits[:9]
            self.target_input.setText(self._format_student_id(digits))
            self.target_input.setCursorPosition(len(self.target_input.text()))
            self.target_input.setFocus()
            return
        self.target_input.insert(text)
        self.target_input.setFocus()

    def _backspace(self):
        if self.target_input is None:
            return
        numeric_format = self.target_input.property("numeric_format")
        if numeric_format == "student_id":
            digits = self._student_id_digits()[:-1]
            self.target_input.setText(self._format_student_id(digits))
            self.target_input.setCursorPosition(len(self.target_input.text()))
            self.target_input.setFocus()
            return
        self.target_input.backspace()
        self.target_input.setFocus()

    def _student_id_digits(self):
        """Return only the numeric characters from the current student id input."""
        if self.target_input is None:
            return ""
        return "".join(ch for ch in self.target_input.text() if ch.isdigit())

    def _format_student_id(self, digits):
        """Format student id as YYYY-NNNNN while typing."""
        if len(digits) <= 4:
            return digits
        return f"{digits[:4]}-{digits[4:9]}"

    def _enter(self):
        self.hide()
        if self.target_input is not None:
            self.target_input.clearFocus()
        self.target_input = None


class StudentKiosk(QWidget):
    """Main student kiosk interface."""

    def __init__(self):
        super().__init__()
        self.db = get_database()
        self.background_source = Path(__file__).resolve().parent / "Background Olfu bw.jpg"
        self.background_pixmap = QPixmap(str(self.background_source))
        self.logo_1_source = Path(__file__).resolve().parent / "OLFU LOGO 1.jpg"
        self.logo_2_source = Path(__file__).resolve().parent / "OLFU LOGO 2.png"
        self.phone_number_enabled = self.db.get_app_settings().get(
            "phone_number_enabled",
            True,
        )
        self._setup_ui()
        self.settings_timer = QTimer(self)
        self.settings_timer.timeout.connect(self._refresh_phone_field_setting)
        self.settings_timer.start(5000)

    def _setup_ui(self):
        """Setup the kiosk UI."""
        self.setWindowTitle("Student Kiosk - Get Your Ticket")
        self.setMinimumSize(1280, 820)
        self.setStyleSheet(
            """
            StudentKiosk {
                background: #dfe6df;
            }
            QFrame#pageOverlay {
                background: rgba(245, 248, 245, 176);
            }
            QLabel, QPushButton, QLineEdit, QComboBox {
                color: #203126;
                font-family: "Segoe UI";
            }
            QFrame#topBar {
                background: rgba(247, 250, 247, 232);
                border: none;
                border-radius: 0px;
            }
            QFrame#sidePanel {
                background: transparent;
            }
            QLabel#brandLogo {
                color: #0b9b4a;
                font-size: 30px;
                font-weight: 800;
            }
            QLabel#brandName {
                color: #0b9b4a;
                font-size: 27px;
                font-weight: 800;
            }
            QLabel#headerLogo {
                background: transparent;
            }
            QLabel#miniBrand {
                color: #0b9b4a;
                font-size: 22px;
                font-weight: 800;
            }
            QLabel#terminalName {
                color: #516257;
                font-size: 16px;
            }
            QPushButton#sideButton {
                background: transparent;
                color: #294032;
                border: 2px solid transparent;
                border-radius: 18px;
                padding: 20px 22px;
                text-align: left;
                font-size: 16px;
                font-weight: 600;
            }
            QPushButton#sideButton:hover {
                background: rgba(255, 255, 255, 0.62);
            }
            QPushButton#sideButton[active="true"] {
                background: rgba(255, 255, 255, 0.96);
                color: #0b9b4a;
            }
            QFrame#card {
                background: rgba(255, 255, 255, 0.96);
                border-radius: 34px;
                border: 1px solid #e3ebe3;
            }
            QLabel#cardTitle {
                color: #18241b;
                font-size: 42px;
                font-weight: 800;
            }
            QLabel#cardSubtitle {
                color: #55665a;
                font-size: 17px;
            }
            QLabel#fieldLabel {
                color: #33483a;
                font-size: 14px;
                font-weight: 700;
            }
            QLineEdit, QComboBox {
                background: rgba(237, 242, 238, 0.96);
                color: #172019;
                border: 2px solid #edf2ee;
                border-radius: 16px;
                padding: 16px 18px;
                font-size: 14px;
                min-height: 34px;
            }
            QLineEdit:focus, QComboBox:focus {
                border: 2px solid #0b9b4a;
                background: #f7fbf8;
            }
            QLineEdit::placeholder {
                color: #9daea0;
            }
            QComboBox {
                padding-right: 32px;
            }
            QComboBox::drop-down {
                border: none;
                width: 30px;
            }
            QComboBox::down-arrow {
                image: none;
                width: 0px;
                height: 0px;
            }
            QComboBox QAbstractItemView {
                background: #f7fbf8;
                color: #203126;
                border: 1px solid #d7e3d8;
                selection-background-color: #0b9b4a;
                selection-color: #ffffff;
                outline: 0;
                padding: 6px;
            }
            QPushButton#submitButton {
                background: #0a8c3c;
                color: white;
                border: none;
                border-radius: 18px;
                padding: 22px;
                font-size: 22px;
                font-weight: 800;
            }
            QPushButton#submitButton:hover {
                background: #087632;
            }
            QPushButton#submitButton:pressed {
                background: #066229;
            }
            QFrame#infoBox {
                background: rgba(242, 247, 242, 0.96);
                border-left: 4px solid #0b9b4a;
                border-radius: 18px;
            }
            QLabel#infoIcon {
                color: #0b9b4a;
                font-size: 22px;
                font-weight: 800;
            }
            QLabel#infoText {
                color: #304336;
                font-size: 15px;
            }
            QFrame#touchKeyboard {
                background: rgba(36, 46, 61, 0.98);
                border: 1px solid rgba(88, 104, 128, 0.75);
                border-radius: 28px;
            }
            QPushButton#keyboardKey,
            QPushButton#keyboardDeleteKey,
            QPushButton#keyboardEnterKey,
            QPushButton#keyboardCloseKey {
                background: #475368;
                color: #f2f5f8;
                border: none;
                border-radius: 14px;
                font-size: 20px;
                font-weight: 700;
                padding: 12px 14px;
            }
            QPushButton#keyboardKey:hover,
            QPushButton#keyboardDeleteKey:hover {
                background: #56647c;
            }
            QPushButton#keyboardDeleteKey {
                background: #c62828;
            }
            QPushButton#keyboardDeleteKey:hover {
                background: #b71c1c;
            }
            QPushButton#keyboardEnterKey {
                background: #0a8c3c;
            }
            QPushButton#keyboardEnterKey:hover {
                background: #087632;
            }
            QPushButton#keyboardCloseKey {
                background: #2d3748;
                font-size: 16px;
                padding: 10px 14px;
            }
            QPushButton#keyboardCloseKey:hover {
                background: #3a4659;
            }
            """
        )

        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        page_overlay = QFrame()
        page_overlay.setObjectName("pageOverlay")
        overlay_layout = QVBoxLayout(page_overlay)
        overlay_layout.setContentsMargins(0, 0, 0, 0)
        overlay_layout.setSpacing(0)
        root_layout.addWidget(page_overlay)

        top_bar = QFrame()
        top_bar.setObjectName("topBar")
        top_bar.setFixedHeight(86)
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(42, 18, 42, 18)
        top_layout.setSpacing(10)

        logo_1 = self._create_logo_label(self.logo_1_source, 42)
        top_layout.addWidget(logo_1)

        logo_2 = self._create_logo_label(self.logo_2_source, 42)
        top_layout.addWidget(logo_2)

        brand_name = QLabel("TapNQue")
        brand_name.setObjectName("brandName")
        top_layout.addWidget(brand_name)
        top_layout.addStretch()

        overlay_layout.addWidget(top_bar)

        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(28, 18, 32, 32)
        body_layout.setSpacing(30)
        overlay_layout.addWidget(body)

        side_panel = QFrame()
        side_panel.setObjectName("sidePanel")
        side_panel.setFixedWidth(270)
        side_layout = QVBoxLayout(side_panel)
        side_layout.setContentsMargins(10, 8, 10, 12)
        side_layout.setSpacing(22)

        side_layout.addSpacing(8)

        side_brand = QLabel("TapNQue")
        side_brand.setObjectName("miniBrand")
        side_layout.addWidget(side_brand)

        side_terminal = QLabel("Kiosk Terminal 01")
        side_terminal.setObjectName("terminalName")
        side_layout.addWidget(side_terminal)

        side_layout.addSpacing(28)

        checkin_button = QPushButton("->  Check In")
        checkin_button.setObjectName("sideButton")
        checkin_button.setProperty("active", True)
        checkin_button.setCursor(Qt.PointingHandCursor)
        side_layout.addWidget(checkin_button)
        side_layout.addStretch()

        body_layout.addWidget(side_panel, 0, Qt.AlignTop)

        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(76, 56, 76, 48)
        card_layout.setSpacing(26)

        title = QLabel("Queue Registration")
        title.setObjectName("cardTitle")
        title.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(title)

        subtitle = QLabel("Please provide your details to receive your service ticket.")
        subtitle.setObjectName("cardSubtitle")
        subtitle.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(subtitle)

        card_layout.addSpacing(12)

        form_grid = QGridLayout()
        form_grid.setHorizontalSpacing(36)
        form_grid.setVerticalSpacing(18)

        name_label = QLabel("STUDENT NAME")
        name_label.setObjectName("fieldLabel")
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("ex Juan Dela Cruz")

        id_label = QLabel("STUDENT NUMBER")
        id_label.setObjectName("fieldLabel")
        self.id_input = QLineEdit()
        self.id_input.setPlaceholderText("2023-00000")
        self.id_input.setProperty("numeric_format", "student_id")

        email_label = QLabel("EMAIL ADDRESS")
        email_label.setObjectName("fieldLabel")
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("student@.edu")

        self.phone_label = QLabel("PHONE NUMBER")
        self.phone_label.setObjectName("fieldLabel")
        self.phone_input = QLineEdit()
        self.phone_input.setPlaceholderText("09XX XXX XXXX")

        visitor_label = QLabel("VISITOR TYPE")
        visitor_label.setObjectName("fieldLabel")
        self.visitor_combo = QComboBox()
        self.visitor_combo.addItems(
            [
                "Student",
                "Parent",
                "Guardian",
                "PWD",
            ]
        )

        purpose_label = QLabel("PURPOSE OF VISIT")
        purpose_label.setObjectName("fieldLabel")
        self.purpose_combo = QComboBox()
        self.purpose_combo.addItems(
            [
                "Select an option",
                "Enrollment",
                "Student Permit",
                "Grades",
                "Clearance",
                "Special Exam",
                "Others",
            ]
        )

        form_grid.addWidget(name_label, 0, 0)
        form_grid.addWidget(id_label, 0, 1)
        form_grid.addWidget(self.name_input, 1, 0)
        form_grid.addWidget(self.id_input, 1, 1)
        form_grid.addWidget(email_label, 2, 0)
        form_grid.addWidget(self.phone_label, 2, 1)
        form_grid.addWidget(self.email_input, 3, 0)
        form_grid.addWidget(self.phone_input, 3, 1)
        form_grid.addWidget(visitor_label, 4, 0)
        form_grid.addWidget(purpose_label, 4, 1)
        form_grid.addWidget(self.visitor_combo, 5, 0)
        form_grid.addWidget(self.purpose_combo, 5, 1)
        self._apply_phone_field_visibility()

        card_layout.addLayout(form_grid)
        card_layout.addSpacing(22)

        self.submit_btn = QPushButton("GET TICKET")
        self.submit_btn.setObjectName("submitButton")
        self.submit_btn.setCursor(Qt.PointingHandCursor)
        self.submit_btn.clicked.connect(self._submit_ticket)
        card_layout.addWidget(self.submit_btn)

        info_box = QFrame()
        info_box.setObjectName("infoBox")
        info_layout = QHBoxLayout(info_box)
        info_layout.setContentsMargins(26, 24, 26, 24)
        info_layout.setSpacing(16)

        info_icon = QLabel("i")
        info_icon.setObjectName("infoIcon")
        info_icon.setAlignment(Qt.AlignCenter)
        info_icon.setFixedWidth(22)
        info_layout.addWidget(info_icon, 0, Qt.AlignTop)

        info_text = QLabel(
            "Your digital ticket will be displayed after submission."
        )
        info_text.setObjectName("infoText")
        info_text.setWordWrap(True)
        info_layout.addWidget(info_text)

        card_layout.addWidget(info_box)
        body_layout.addWidget(card, 1)

        self.keyboard = TouchKeyboardWidget(self)

        for field, keyboard_type in (
            (self.name_input, "alpha"),
            (self.id_input, "numeric"),
            (self.email_input, "alpha"),
            (self.phone_input, "numeric"),
        ):
            field.setProperty("keyboard_type", keyboard_type)
            field.installEventFilter(self)

        self._apply_fonts()
        self._position_keyboard()

    def _apply_fonts(self):
        """Set a few explicit fonts for visual hierarchy."""
        self.setFont(QFont("Segoe UI", 11))

    def _create_logo_label(self, image_path: Path, height: int) -> QLabel:
        """Create a scaled logo label for the header."""
        label = QLabel()
        label.setObjectName("headerLogo")
        label.setFixedHeight(height)
        label.setAlignment(Qt.AlignCenter)

        pixmap = QPixmap(str(image_path))
        if not pixmap.isNull():
            scaled = pixmap.scaledToHeight(height, Qt.SmoothTransformation)
            label.setPixmap(scaled)
            label.setFixedWidth(scaled.width())
        else:
            label.setFixedWidth(height)

        return label

    def eventFilter(self, watched, event):
        if event.type() == QEvent.FocusIn and isinstance(watched, QLineEdit):
            keyboard_type = watched.property("keyboard_type") or "alpha"
            self.keyboard.attach_target(watched, keyboard_type)
            self._position_keyboard()
        return super().eventFilter(watched, event)

    def _position_keyboard(self):
        """Float the keyboard above the bottom of the window like a tablet keyboard."""
        keyboard_width = min(860, max(520, self.width() - 120))
        if self.keyboard.width() != keyboard_width:
            self.keyboard.setFixedWidth(keyboard_width)

        x = (self.width() - self.keyboard.width()) // 2
        y = self.height() - self.keyboard.height() - 18
        self.keyboard.move(max(20, x), max(100, y))

    def _apply_phone_field_visibility(self):
        """Apply the current phone field setting to the form."""
        self.phone_label.setVisible(self.phone_number_enabled)
        self.phone_input.setVisible(self.phone_number_enabled)
        if not self.phone_number_enabled:
            self.phone_input.clear()
            if hasattr(self, "keyboard") and self.keyboard.target_input is self.phone_input:
                self.keyboard.hide()

    def _refresh_phone_field_setting(self):
        """Keep the kiosk form in sync with admin settings."""
        enabled = self.db.get_cached_app_settings().get("phone_number_enabled", True)
        if enabled == self.phone_number_enabled:
            return

        self.phone_number_enabled = enabled
        self._apply_phone_field_visibility()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._position_keyboard()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape and self.isFullScreen():
            self.showNormal()
            return
        super().keyPressEvent(event)

    def paintEvent(self, event):
        """Draw the background image behind the UI."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)

        if not self.background_pixmap.isNull():
            scaled = self.background_pixmap.scaled(
                self.size(),
                Qt.KeepAspectRatioByExpanding,
                Qt.SmoothTransformation,
            )
            x = (self.width() - scaled.width()) // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)

        painter.fillRect(self.rect(), Qt.transparent)
        super().paintEvent(event)

    def _submit_ticket(self):
        """Handle ticket submission."""
        name = self.name_input.text().strip()
        student_id = self.id_input.text().strip()
        email = self.email_input.text().strip()
        phone = self.phone_input.text().strip() if self.phone_number_enabled else ""
        visitor_type = self.visitor_combo.currentText()
        purpose = self.purpose_combo.currentText()

        if not name or not student_id:
            QMessageBox.warning(
                self,
                "Missing Information",
                "Please enter your student name and student number.",
            )
            return

        if purpose == "Select an option":
            QMessageBox.warning(
                self,
                "Missing Information",
                "Please select your purpose of visit.",
            )
            return

        try:
            ticket = self.db.create_ticket(
                name,
                student_id,
                email,
                phone,
                purpose,
                visitor_type,
            )
            queue_position = 1
            waiting_queue = self.db.get_waiting_queue()
            for index, queued_ticket in enumerate(waiting_queue, start=1):
                if queued_ticket.get("ticket_number") == ticket["ticket_number"]:
                    queue_position = index
                    break

            if email and is_email_configured():
                send_ticket_email(
                    email,
                    name,
                    ticket["ticket_number"],
                    queue_position,
                    purpose,
                )
                email_sent = True
            else:
                email_sent = False

            self.keyboard.hide()
            confirmation = TicketCreatedDialog(
                ticket=ticket,
                queue_position=queue_position,
                purpose=purpose,
                email_sent=email_sent,
                parent=self,
            )
            confirmation.resize(960, 640)
            confirmation.exec()
            self._clear_form()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create ticket: {str(e)}")

    def _clear_form(self):
        """Clear all input fields."""
        self.name_input.clear()
        self.id_input.clear()
        self.email_input.clear()
        self.phone_input.clear()
        self.visitor_combo.setCurrentIndex(0)
        self.purpose_combo.setCurrentIndex(0)
        self.keyboard.hide()


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    window = StudentKiosk()
    loading = LoadingScreen(window)
    loading.showFullScreen()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
