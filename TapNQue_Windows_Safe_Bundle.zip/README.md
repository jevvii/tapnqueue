# TapNQue - Campus Queue Management System

A desktop queuing and ticketing solution built for educational institutions (e.g., Our Lady of Fatima University - OLFU) using Python and PySide6 (Qt).

---

## 🏗️ Architecture & Stations

TapNQue provides 4 integrated stations that operate seamlessly against a local SQLite database:

| Station | Entry Point | Target Audience | Key Capabilities |
| :--- | :--- | :--- | :--- |
| **Main Launcher** | `python main.py` | Administrator / Central Hub | Multi-station dashboard launcher. |
| **Student Kiosk** | `python run_kiosk.py` | Students & Visitors | Touchscreen queue entry, student ID formatting, on-screen touch keyboard, email receipts. |
| **Live Display Monitor** | `python run_monitor.py` | Waiting Area Monitors | TV-friendly "Now Serving" display, upcoming queue cards (Up Next 1–6), light/dark themes, clock. |
| **Staff Service Desk** | `python run_staff.py` | Counter Staff | Call next, recall, complete ticket, priority highlights (PWD, Parent, Student), ticket history. |
| **Super Admin Console** | `python run_admin.py` | Department Supervisors | Operational analytics, queue health heuristics, data export, settings toggle. |

---

## 📁 Project Directory Structure

```
Project6/
├── assets/                  # Brand & media assets
│   ├── audio/               # Notification sounds & specs
│   └── images/              # Logos and background artwork
├── data/                    # Persistent data storage
│   ├── admin_users.json     # Salted SHA-256 hashed credentials
│   ├── kiosk.db             # Primary SQLite database (WAL mode)
│   └── queue_db.json        # Legacy JSON archive
├── docs/                    # Architectural & audit documentation
│   └── PROJECT_AUDIT_AND_REVIEW.md
├── src/
│   └── tapnque/             # Main Python package
│       ├── __init__.py
│       ├── __main__.py      # python -m tapnque entrypoint
│       ├── config.py        # Centralized settings & path resolution
│       ├── core/            # Database engine & authentication
│       │   ├── auth.py
│       │   └── database.py
│       ├── services/        # Non-blocking async email delivery
│       │   └── email_service.py
│       ├── ui/              # PySide6 graphical user interfaces
│       │   ├── launcher.py
│       │   ├── kiosk.py
│       │   ├── monitor.py
│       │   ├── live_display.py
│       │   ├── staff.py
│       │   ├── super_admin.py
│       │   └── components/  # Animations, touch keyboard, dialogs
│       └── cli/             # Administrative CLI commands
│           └── set_admin_password.py
├── tests/                   # Automated unit test suite
│   ├── test_auth.py
│   └── test_database.py
├── main.py                  # Standard launcher
├── run_kiosk.py             # Direct kiosk runner
├── run_monitor.py           # Direct monitor runner
├── run_staff.py             # Direct staff runner
├── run_admin.py             # Direct admin runner
├── pyproject.toml           # Modern PEP 518/621 packaging
├── requirements.txt         # Core dependencies
├── requirements-dev.txt     # Developer tools
├── .env.example             # Environment template
└── .gitignore               # Clean VCS ignore rules
```

---

## 🚀 Getting Started

### 1. Requirements
- Python 3.8 or newer
- PySide6 (`pip install -r requirements.txt`)

### 2. Installation
```bash
# Create and activate a virtual environment
python3 -m venv .venv
source .venv/bin/activate   # Linux/macOS
# .venv\Scripts\activate    # Windows

# Install dependencies
pip install -r requirements.txt
```

### 3. Launching Applications

#### Option A: Unified Launcher (Recommended)
```bash
python main.py
# or
python -m tapnque
```

#### Option B: Dedicated Station Runners
```bash
python run_kiosk.py      # Student Kiosk
python run_monitor.py    # Public TV Monitor
python run_staff.py      # Counter Staff Desk
python run_admin.py      # Super Admin Console
```

*(Legacy root entry points like `python student_kiosk.py` and `python main_launcher.py` remain fully compatible as shims).*

---

## 🔐 Authentication & Passwords

Protected portals (**Staff Admin** and **Super Admin**) require local credentials.

Default logins (**change on first run — these are first-time-setup defaults only**):
- **Staff Admin**: username `staff`, password `staff123`
- **Super Admin**: username `admin`, password `admin123`

To update credentials securely:
```bash
python -m tapnque.cli.set_admin_password staff new_staff_user strong_password_here
python -m tapnque.cli.set_admin_password super_admin new_admin_user strong_password_here
```

---

## 📧 Email Notifications (Optional)

To enable automatic email dispatch when tickets are created, called, or completed:
1. Copy `.env.example` to `.env`
2. Set your department Gmail and App Password:
   ```env
   TAPNQUE_SENDER_EMAIL=your_dept@gmail.com
   TAPNQUE_SENDER_PASSWORD=your_16_char_app_password
   ```
*If unconfigured, the system automatically runs in silent offline mode without UI delays.*

---

## 📱 SMS Notifications (Tier 2 – Pure Software)

TapNQue dispatches SMS alerts on ticket creation, counter call/recall, and (optionally) completion via the **Semaphore** cloud SMS REST API — no GSM hardware required.

- **Mock Mode is ON by default**: all SMS flows run locally with zero credits and no internet. Dispatches are printed to the terminal and inspectable via **Settings → VIEW MOCK SMS LOGS** in Super Admin.
- **Super Admin Settings tab**: master SMS ON/OFF, Mock ↔ Live switch, per-event Completed-SMS toggle, masked Semaphore API key field, sender ID, and customizable message templates — all persisted in SQLite.
- **Going live**: paste your Semaphore API key in Settings, save, then **SWITCH TO LIVE GATEWAY**. If live mode is selected without a key, the badge warns that dispatches are only simulated.
- **Phone validation**: Philippine mobiles (`09XX…`, `+639XX…`, with dashes/spaces) are validated at the kiosk before ticket creation.
- Full setup and demo walkthrough: [`docs/09-09-2026_TapNQue_Comprehensive_System_Guide_and_SMS_Manual.md`](docs/09-09-2026_TapNQue_Comprehensive_System_Guide_and_SMS_Manual.md).

---

## 🧪 Running Unit Tests

The suites cover the database engine, authentication, and the full SMS subsystem:
```bash
pip install -e . pytest     # one-time: install package + test runner
pytest                      # 22 passed
# or without an install:
PYTHONPATH=src python3 -m unittest discover tests
```
