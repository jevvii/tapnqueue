"""
TapNQue Test Suite
"""
